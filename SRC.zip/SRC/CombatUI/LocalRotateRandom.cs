﻿using UnityEngine;
using System.Collections;

public class LocalRotateRandom : MonoBehaviour
{

	private CardboardHead head;//Get the cardboard head to detect whether the player is aiming at the enemy
	private int counter;
	private bool lockOn;//If the player is aiming at the enemy, the aim Sight will not rotate, otherwise it will rotate

	private GameObject thePlane;//The enemy

	private GameObject gameController;

	public GameObject theGun;// The Gun

	// Use this for initialization
	void Start ()
	{
		counter = 0;
		lockOn = false;
		gameController = GameObject.FindGameObjectWithTag ("GameController");
	}
	
	// Update is called once per frame
	void LateUpdate ()
	{
		if(gameController.GetComponent<GameController>().isCombatCondition())
			thePlane = GameObject.FindGameObjectWithTag ("Enemy");
		if (!gameController.GetComponent<GameController> ().isCombatCondition ()||(gameController.GetComponent<GameController> ().getPlaneNum()==0))
			return;
		counter++;
		//Check whether the player is already aiming at the enemy, if yes, do not rotate
		if (!lockOn)
			if (counter % 600 <= 300)
				transform.Rotate (new Vector3 (0, 0.2f, 0));
			else
				transform.Rotate (new Vector3 (0, -0.2f, 0));
		RaycastHit hit;
		thePlane = GameObject.FindGameObjectWithTag ("Enemy");
		head = Camera.main.GetComponent<StereoController> ().Head;
		bool isLookedAt = thePlane.GetComponent<Collider> ().Raycast (head.Gaze, out hit, Mathf.Infinity);
		//If the player is aiming at the enemy
		if (isLookedAt) {
			//Shoot normal bullets
			if(counter % 10 == 0){
				theGun.GetComponent<GunController>().newBullet(transform.position);
			}
			lockOn = true;
			//The aim sight should change to tell the player that he is aiming at the enemy
			if (counter % 60 >= 30)
				transform.localScale = new Vector3 (transform.localScale.x - 0.0005f, transform.localScale.y - 0.0005f, transform.localScale.z - 0.0005f);
			else
				transform.localScale = new Vector3 (transform.localScale.x + 0.0005f, transform.localScale.y + 0.0005f, transform.localScale.z + 0.0005f);
		} else { 				
			transform.localScale = new Vector3 (0.04f, 0.04f, 0.04f);
			lockOn = false;
		}

	}
}

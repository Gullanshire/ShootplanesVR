﻿using UnityEngine;
using System.Collections;

public class AimMove : MonoBehaviour {
	private CardboardHead head;

	private GameObject thePlane;

	private GameObject missleLock;

	private GameObject gameController;

	private bool missleFlag;

	private int counter;

	public GameObject theGun;

	// Use this for initialization
	void Start () {
		counter = 0;
		missleFlag = true;
		missleLock = GameObject.FindGameObjectWithTag ("Locker");
		gameController = GameObject.FindGameObjectWithTag ("GameController");
	}
	
	// Update is called once per frame
	void LateUpdate () {
		if(gameController.GetComponent<GameController>().isCombatCondition())
			thePlane = GameObject.FindGameObjectWithTag ("Enemy");
		if (!gameController.GetComponent<GameController> ().isCombatCondition ()||(gameController.GetComponent<GameController> ().getPlaneNum()==0))
			return;

		if (!missleFlag) {
			if(counter<=300)
				counter++;
			else{
				missleFlag = true;
				counter = 0;
				missleLock.transform.Rotate(new Vector3(-90,0,0));
			}
		}
		RaycastHit hit;
		thePlane = GameObject.FindGameObjectWithTag ("Enemy");
		head = Camera.main.GetComponent<StereoController> ().Head;
		bool isLookedAt = thePlane.GetComponent<Collider> ().Raycast (head.Gaze, out hit, Mathf.Infinity);
		if (isLookedAt && missleFlag) {
			var speed = 0.1f;
			if (transform.localPosition.x >= -4)
				transform.Translate (Vector3.left * Time.deltaTime * speed);
			else {
				//Shoot a missle
				theGun.GetComponent<GunController>().newMissle();

				missleFlag = false;
				missleLock.transform.Rotate(new Vector3(90,0,0));
			}
		} else
			transform.localPosition = new Vector3 (4, transform.localPosition.y, transform.localPosition.z);
	}
}

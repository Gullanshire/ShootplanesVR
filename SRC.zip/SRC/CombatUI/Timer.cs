﻿using UnityEngine;
using System.Collections;

public class Timer : MonoBehaviour {
	private int timeL;
	private int counter;
	private Vector3 startScale;

	public GameObject mygameController;

	// Use this for initialization
	void Start () {
		counter = 0;
		timeL = 1800;
		startScale = transform.localScale;
		mygameController = GameObject.FindGameObjectWithTag("GameController");
	}
	
	// Update is called once per frame
	void Update () {
		if (!mygameController.GetComponent<GameController> ().isCombatCondition ()) {
			counter = 0;
			transform.localScale = startScale;
			return;
		}
		counter++;
		transform.localScale = new Vector3(startScale.x,startScale.y * (timeL - counter) * 1.0f / timeL,startScale.z);
		if (counter>=timeL) {
			counter = 0;
			transform.localScale = startScale;
			GameObject rMissle = GameObject.FindGameObjectWithTag("Missle");
			if(rMissle != null){
				Destroy(rMissle);
			}
			GameObject theEnemy = GameObject.FindGameObjectWithTag("Enemy");
			theEnemy.tag = "EnemySub";
			Debug.Log("change tag");
			GameObject gameController = GameObject.FindGameObjectWithTag("GameController");
			gameController.GetComponent<GameController>().flyCondition();
		}
	}

	public void resetTimer(){
		counter = 0;
	}
}

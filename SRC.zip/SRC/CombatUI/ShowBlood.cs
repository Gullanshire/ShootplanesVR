﻿using UnityEngine;
using System.Collections;

public class ShowBlood : MonoBehaviour {

	private int lastBlood;
	private float startX;
	private float startSX;
	private GameObject thePlane;

	// Use this for initialization
	void Start () {
		lastBlood = 1000;
		startX = transform.localPosition.x;
		startSX = transform.localScale.x;
	}
	
	// Update is called once per frame
	void LateUpdate () {
		thePlane = GameObject.FindGameObjectWithTag ("Enemy");
		if (thePlane != null) {
			int blood = thePlane.GetComponent<dealDamage> ().rBlood ();
			if (blood != lastBlood) {
				transform.localScale = new Vector3 (startSX * blood * 1.0f / 1000, transform.localScale.y, transform.localScale.z);
				transform.localPosition = new Vector3 (startX - 0.175f * (1000 - blood) / 1000, transform.localPosition.y, transform.localPosition.z);
				lastBlood = blood;
			}
		}
	}
}

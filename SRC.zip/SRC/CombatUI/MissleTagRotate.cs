﻿using UnityEngine;
using System.Collections;

public class MissleTagRotate : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		var speed = 2.0f;
		transform.RotateAround(new Vector3(1,0,0),Time.deltaTime * speed);
	}
}

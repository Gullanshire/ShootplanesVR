using UnityEngine;
using System.Collections;

public class asteroidControl : MonoBehaviour {

	public GameObject head;
	private Vector3 planePosition;
	private float distanceToPlane;
	private Vector3 temp2;

	// Use this for initialization
	void Start () {
		head=GameObject.FindGameObjectWithTag("Head");
		transform.localScale = new Vector3 (Random.Range (0.001f, 0.5f), Random.Range (0.001f, 0.5f), Random.Range (0.01f, 0.5f));
		transform.rotation = Random.rotation;
		transform.position=rePosition2 ();
	}
	
	// Update is called once per frame
	void Update () {
		planePosition = head.transform.position;
		distanceToPlane = Mathf.Sqrt ((planePosition.x-transform.position.x)*(planePosition.x-transform.position.x)+(planePosition.y-transform.position.y)*(planePosition.y-transform.position.y)+(planePosition.z-transform.position.z)*(planePosition.z-transform.position.z));

		if (distanceToPlane >= Mathf.Sqrt(235200f)) 
			transform.position=rePosition ();

	}

	Vector3 rePosition(){

		int temp;
		float a, b, c;

		temp=Random.Range (0, 32000);
		if (temp%2 == 0)
			a = Random.Range (planePosition.x + 100f, planePosition.x + 280f);
		else
			a = Random.Range (planePosition.x - 100f, planePosition.x - 280f);

		temp=Random.Range (0, 32000);
		if (temp%2 == 0)
			b = Random.Range (planePosition.y + 100f, planePosition.y + 280f);
		else
			b = Random.Range (planePosition.y - 100f, planePosition.y - 280f);

		temp=Random.Range (0, 32000);
		if (temp%2 == 0)
			c = Random.Range (planePosition.z + 100f, planePosition.z + 280f);
		else
			c = Random.Range (planePosition.z - 100f, planePosition.z - 280f);

		temp2 = new Vector3 (a, b, c);
		return temp2;
	}

	//Allow the asteroid to stay close when first spawn
	Vector3 rePosition2(){
		int temp;
		float a, b, c;

		temp=Random.Range (0, 32000);
		if (temp%2 == 0)
			a = Random.Range (planePosition.x + 10f, planePosition.x + 280f);
		else
			a = Random.Range (planePosition.x - 10f, planePosition.x - 280f);

		temp=Random.Range (0, 32000);
		if (temp%2 == 0)
			b = Random.Range (planePosition.y + 10f, planePosition.y + 280f);
		else
			b = Random.Range (planePosition.y - 10f, planePosition.y - 280f);

		temp=Random.Range (0, 32000);
		if (temp%2 == 0)
			c = Random.Range (planePosition.z + 10f, planePosition.z + 280f);
		else
			c = Random.Range (planePosition.z - 10f, planePosition.z - 280f);
		
		temp2 = new Vector3 (a, b, c);
		return temp2;
	}
}

﻿using UnityEngine;
using System.Collections;

public class missleMove : MonoBehaviour {

	private float missleSpeed;
	private GameObject recentEnemy;

	// Use this for initialization
	void Start () {
		missleSpeed = 10.0f;
		recentEnemy = GameObject.FindGameObjectWithTag ("Enemy");
	}
	
	// Update is called once per frame
	void Update () {
		recentEnemy = GameObject.FindGameObjectWithTag ("Enemy");
		if(recentEnemy != null)
			transform.LookAt(recentEnemy.transform);
		transform.Translate(Vector3.forward * Time.deltaTime * missleSpeed);
	}

	void OnTriggerEnter(Collider cInfo){
		//Destroy (this);
		if(cInfo.tag == "Enemy")
			Destroy (gameObject);
	}
}

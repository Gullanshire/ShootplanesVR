﻿using UnityEngine;
using System.Collections;

public class GunController : MonoBehaviour {

	public GameObject bullet;
	public GameObject missle;

	private GameObject thePlane;

	private GameObject gameController;

	private int counter;

	public GameObject[] objBullet;

	public int index;

	private float bulletSpeed;

	// Use this for initialization
	void Start () {
		counter = 0;
		index = 0;
		bulletSpeed = 20.0f;
		gameController = GameObject.FindGameObjectWithTag ("GameController");
	}
	
	// Update is called once per frame
	void Update () {
//		if (index > 0){
//			objBullet = GameObject.FindGameObjectsWithTag("bullets;
//			for (int i = 0; i < index; i++) {
//				if(Mathf.Abs(objBullet[i].transform.position.x - thePlane.transform.position.x) <= 0.05 && Mathf.Abs(objBullet[i].transform.position.y - thePlane.transform.position.y) <= 0.05 && Mathf.Abs(objBullet[i].transform.position.z - thePlane.transform.position.z) <= 0.05){
//					objBullet[i].renderer.enabled = false;
//				}
//				objBullet[i].transform.LookAt(thePlane.transform);
//				objBullet[i].transform.Translate(Vector3.forward * (1.0f) * Time.deltaTime * bulletSpeed);
//			}
//		}
		//GameObject obj = (GameObject)GameObject.Instantiate(bullet,transform.position,Quaternion.identity);
//		for (int i = 0; i <= index; i++) {
//			objBullet[i].transform.Rotate(thePlane.transform.eulerAngles);
//			objBullet[i].transform.Translate(Vector3.left * (1.0f) * Time.deltaTime * bulletSpeed);
//		}
	}

	public void newBullet(Vector3 startPosition){
		var myAudio = GetComponent<AudioSource>();
		myAudio.Play ();
		//objBullet[index] = (GameObject)GameObject.Instantiate(bullet,startPosition,Quaternion.identity);
		GameObject obj = (GameObject)GameObject.Instantiate(bullet,transform.position,Quaternion.identity);
		obj.tag = "bullets";
		index++;
	}

	public void newMissle(){
		var myAudio = GetComponent<AudioSource>();
		myAudio.Play ();
		GameObject obj = (GameObject)GameObject.Instantiate(missle,transform.position,Quaternion.identity);
	}

	public int returnIndex(){
		return index;
	}
}

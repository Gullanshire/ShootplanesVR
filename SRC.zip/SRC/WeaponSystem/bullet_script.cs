﻿using UnityEngine;
using System.Collections;

public class bullet_script : MonoBehaviour {

	private float bulletSpeed;
	private Vector3 movedelta;
	private GameObject recentEnemy;
	public GameObject boomb;

	// Use this for initialization
	void Start () {
		bulletSpeed = 25f;
		recentEnemy = GameObject.FindGameObjectWithTag ("Enemy");
	}
	
	// Update is called once per frame
	void LateUpdate () {
		recentEnemy = GameObject.FindGameObjectWithTag ("Enemy");
		if(recentEnemy != null)
			transform.LookAt(recentEnemy.transform);
		transform.Translate(Vector3.forward * (1.0f) * Time.deltaTime * bulletSpeed);
	}


	void OnTriggerEnter(Collider cInfo){
		//Destroy (this);
		if (cInfo.tag == "Enemy") {
			//GameObject obj = (GameObject)GameObject.Instantiate (boomb, transform.position, Quaternion.identity);
			Destroy (gameObject);
		}
	}
}

﻿using UnityEngine;
using System.Collections;

public class bloodControl : MonoBehaviour {

	public GameObject gameControllerO;
	private bool winorlose;

	private int blood;
	// Use this for initialization
	void Start () {	
		blood = 1000;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnTriggerEnter (Collider cInfo)
	{
		if (blood > 0) {
			if (cInfo.tag == "bullets")
				blood -= 8;
			else if (cInfo.tag == "Missle")
				blood -= 200;
		} else {
			gameControllerO.GetComponent<GameController>().ifWinOrLose(false);
		}
	}

	public int getBlood () {
		return blood;
	}
}

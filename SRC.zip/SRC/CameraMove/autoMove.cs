﻿using UnityEngine;
using System.Collections;

public class autoMove : MonoBehaviour
{
	private CardboardHead head;
	private Vector3 startingPosition;
	private int counter;
	private Vector3 planePosition;
	public Vector3 randomeShift;

	private GameObject thePlane;
	public float roateteY;
	public float tanRo;

	public GameObject gameController;

	//Variables for fly mode
	private Vector3 planeDirection;
	public float planeSpeed;
	
	private Vector3 headDirection;
	
	private Vector3 tempVector3;

	// Use this for initialization
	void Start ()
	{
		startingPosition = transform.localPosition;	
		counter = 0;

		planeDirection = new Vector3 (0, 0, 1);
		planeSpeed = 0.15f;
		//Random shift vector
		//randomeShift = new Vector3 (Random.value*Random.Range(-1,1), Random.value*Random.Range(-1,1), Random.value*Random.Range(-1,1));
		randomeShift = Random.onUnitSphere;
	}	
	
	// Update is called once per frame
	void LateUpdate ()
	{	
		//Check the condition, whether it is in the combat condition
		//If it is in the combat condition, we catch up the enemy and get into the combat
		if (gameController.GetComponent<GameController> ().isCombatCondition ()) {
			counter++;
			thePlane = GameObject.FindGameObjectWithTag ("Enemy");
			//Get the Plane's Position
			planePosition = thePlane.transform.position;
			//My plane direction
			planeDirection = planePosition - transform.position;
			//My plane speed
//			if(Vector3.Distance(planePosition,transform.position)>=50&& counter % 20 == 0)
//				planeSpeed += 0.001f;
//			if(Vector3.Distance(planePosition,transform.position)<=10&& counter % 20 == 0)
//				planeSpeed -= 0.001f;

			Vector3 tmp;
			tmp = planeDirection * planeSpeed;
			transform.position += tmp;
			//transform.position += randomeShift * 0.025f * ((counter % 120 > 60) ? (120 - counter % 120) : (counter % 120)) * Mathf.Sin (0.75f * (counter % 120) * Mathf.PI / 180);

			if(Vector3.Distance(planePosition,transform.position)<=12)
				planeSpeed = 0.001f;
			else planeSpeed = 0.05f;
			if (counter % 120 == 119) {
				//Random shift vector
				randomeShift = Random.onUnitSphere;
			}

		} else {
			//when in flight condition
			if(gameController.GetComponent<GameController>().isFlightCondition()){
				;
			}else{
				planeSpeed = 0.15f;
				freeFly();//Fly Mode Here
			}
		}
	}

	void freeFly()
	{
		headDirection = Camera.main.GetComponent<StereoController> ().Head.Gaze.direction;

		speedCalculation ();
		
		//update position
		Vector3 tmp;
		tmp = planeDirection * planeSpeed;
		transform.position += tmp;
	}

	void speedCalculation(){
		tempVector3.x=headDirection.x/Mathf.Sqrt(headDirection.x*headDirection.x+headDirection.y*headDirection.y+headDirection.z*headDirection.z);
		tempVector3.y=headDirection.y/Mathf.Sqrt(headDirection.x*headDirection.x+headDirection.y*headDirection.y+headDirection.z*headDirection.z);
		tempVector3.z=headDirection.z/Mathf.Sqrt(headDirection.x*headDirection.x+headDirection.y*headDirection.y+headDirection.z*headDirection.z);
		headDirection.x=tempVector3.x;
		headDirection.y = tempVector3.y;
		headDirection.z = tempVector3.z;
		
		planeDirection.x += headDirection.x;
		planeDirection.y += headDirection.y;
		planeDirection.z += headDirection.z;
		
		tempVector3.x=planeDirection.x/Mathf.Sqrt(planeDirection.x*planeDirection.x+planeDirection.y*planeDirection.y+planeDirection.z*planeDirection.z);
		tempVector3.y=planeDirection.y/Mathf.Sqrt(planeDirection.x*planeDirection.x+planeDirection.y*planeDirection.y+planeDirection.z*planeDirection.z);
		tempVector3.z=planeDirection.z/Mathf.Sqrt(planeDirection.x*planeDirection.x+planeDirection.y*planeDirection.y+planeDirection.z*planeDirection.z);
		planeDirection.x = tempVector3.x;
		planeDirection.y = tempVector3.y;
		planeDirection.z = tempVector3.z;
	}

}

﻿using UnityEngine;
using System.Collections;

public class MoveWithCamera : MonoBehaviour {

	public GameObject Head;
	// Use this for initialization
	void Start () {
		transform.position = Head.transform.position;
	}
	
	// Update is called once per frame
	void Update () {
		transform.position = Head.transform.position;
	}
}

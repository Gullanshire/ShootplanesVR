﻿using UnityEngine;
using System.Collections;

public class flightStart : MonoBehaviour {

	public enum backGround
	{
		exit = 0,
		tutorial = 1,
		level_01 = 2,
		level_02 = 3,
		level_03 = 4,
		back_to_flight = 5
	};

	public Material orangeSky;

	public Material otherSky;

	public backGround chooseScene;

	public GameObject startBoard;

	public GameObject gameController;

	private CardboardHead head;

	private int counter;

	// Use this for initialization
	void Start () {
		counter = 0;
		head = Camera.main.GetComponent<StereoController> ().Head;
	}
	
	// Update is called once per frame
	void Update () {
		RaycastHit hit;
		head = Camera.main.GetComponent<StereoController> ().Head;
		bool isLookedAt = startBoard.GetComponent<Collider> ().Raycast (head.Gaze, out hit, Mathf.Infinity);
		if (isLookedAt) {
			var speed = 0.1f;
			if (transform.localPosition.x >= -4)
				transform.Translate (Vector3.left * Time.deltaTime * speed);
			else {
				transform.localPosition = new Vector3 (4, transform.localPosition.y, transform.localPosition.z);
				//goes into fly condition
				switch(chooseScene){
				case(backGround.exit):{
					//Application.LoadLevel("DemoScene");
					Application.LoadLevel("Thanks");
					//Application.LoadLevel(6);
				}
					break;
				case(backGround.tutorial):
					//Application.LoadLevel("Tutorial");
					Application.LoadLevel(5);
					break;
				case(backGround.level_01):
					//Application.LoadLevel("DemoScene");
					Application.LoadLevel(1);
					break;
				case(backGround.level_02):
					//Application.LoadLevel("Level_02");//change the second scene
					Application.LoadLevel(2);
					break;
				case(backGround.level_03):
					//Application.LoadLevel("Level_03");//change the third scene
					Application.LoadLevel(3);
					break;
				case(backGround.back_to_flight):
					//Application.LoadLevel("Flight");//change the third scene
					Application.LoadLevel(0);
					break;
				}
			}
		} else
			transform.localPosition = new Vector3 (4, transform.localPosition.y, transform.localPosition.z);
	}
}

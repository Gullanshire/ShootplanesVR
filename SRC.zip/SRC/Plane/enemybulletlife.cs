﻿using UnityEngine;
using System.Collections;

public class enemybulletlife : MonoBehaviour {

	private Vector3 beginposition;// Use this for initialization
	public float speed=25f;
	void Start () {
		beginposition = this.transform.position;
	}
	
	// Update is called once per frame
	void Update () {

		this.transform.position += this.transform.forward * speed * Time.deltaTime;
		if (Vector3.Distance (this.transform.position, beginposition) > 1000)
			Destroy (gameObject);

	
	}

	
}

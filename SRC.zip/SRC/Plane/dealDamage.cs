﻿using UnityEngine;
using System.Collections;

public class dealDamage : MonoBehaviour
{
	public GameObject explosion;
	public GameObject boomb;
	public static int blood;

	private GameObject myTimer;

	// Use this for initialization
	void Start ()
	{
		blood = 1000;
	}
	
	// Update is called once per frame
	void Update ()
	{
		GameObject gameController = GameObject.FindGameObjectWithTag ("GameController");
		if (!gameController.GetComponent<GameController> ().isCombatCondition ())
			blood = 1000;
		//Test Code
//		blood--;
//		if (blood <= 0) {
//			GameObject obj = (GameObject)GameObject.Instantiate (explosion, transform.position, Quaternion.identity);
//			//Instantiate(explosion,transform.position,transform.rotation);
//			Destroy (gameObject);
//		}
	}

	void OnTriggerEnter (Collider cInfo)
	{
		if (blood > 0) {
			if(blood <= 50){
				GameObject objB = (GameObject)GameObject.Instantiate (explosion, transform.position, Quaternion.identity);
				objB.AddComponent<bullet_script>();
			}
			GameObject obj = (GameObject)GameObject.Instantiate (boomb, transform.localPosition, Quaternion.identity);
			obj.AddComponent<bullet_script>();
			if (cInfo.tag == "bullets")
				blood -= 8;
			else if (cInfo.tag == "Missle")
				blood -= 200;
		} else {
			//Instantiate(explosion,transform.position,transform.rotation)
			Destroy (gameObject);
			GameObject gameController = GameObject.FindGameObjectWithTag ("GameController");
			gameController.GetComponent<GameController> ().setPlane (gameController.GetComponent<GameController> ().getPlaneNum () - 1);
			if (gameController.GetComponent<GameController> ().getPlaneNum () <= 0) {
				gameController.GetComponent<GameController> ().flightCondition ();
				blood = 1000;
			}else{
				gameController.GetComponent<GameController>().flyCondition();
				myTimer = GameObject.FindGameObjectWithTag ("Timer");
				myTimer.GetComponent<Timer>().resetTimer();
			}
		}
		
	}

	public int rBlood ()
	{
		return blood;
	}
}

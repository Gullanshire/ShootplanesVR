﻿using UnityEngine;
using System.Collections;

public class LockInFly : MonoBehaviour {

	private GameObject gameController;
	private GameObject flyAim;

	private CardboardHead head;
	
	private int LockCounter;//Used for the planes to be locked in the fly condition
	private bool isLookedAt;
	private bool aimLock;//Store the state whether this plane is being locked or other plane is being locked

	// Use this for initialization
	void Start () {
		LockCounter = 0;
		aimLock = false;
		head = Camera.main.GetComponent<StereoController> ().Head;
		gameController = GameObject.FindGameObjectWithTag ("GameController");
		flyAim = GameObject.FindGameObjectWithTag("FlyAim");
	}
	
	// Update is called once per frame
	void Update () {
		//Only works in free fly condition
		if (!gameController.GetComponent<GameController> ().isFlyCondition())
			return;
		RaycastHit hit;
		head = Camera.main.GetComponent<StereoController> ().Head;
		isLookedAt = GetComponent<Collider> ().Raycast (head.Gaze, out hit, Mathf.Infinity);

		if (isLookedAt) {// is look at
			aimLock = true;
			LockCounter++;
			gameController.GetComponent<GameController>().changeFlyLock(true);
			if(LockCounter >= 90){
				//Lock the enemy
				gameObject.tag = "Enemy";
				Debug.Log("tag change");
				gameController.GetComponent<GameController>().combatCondition();
				LockCounter = 0;
			}
		} else {
			LockCounter = 0;
			if(gameController.GetComponent<GameController>().isFlyLock()){
				if(aimLock){//where this plane is being lock, if not, do not change the lock value of game controller
					gameController.GetComponent<GameController>().changeFlyLock(false);
					aimLock = false;
				}
			}
		}
	}
}

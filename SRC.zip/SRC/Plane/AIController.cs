﻿using UnityEngine;
using System.Collections;

public enum state
{
	Goback,
	Flyaway,
	Attacking,
	CatchUp
	
}

public class AIController : MonoBehaviour
{
	
	public float attackDirection = 0.5f;
	public float distanceLock = float.MaxValue;
	public float distanceAttack=50f;
	public float distanceElude =20f;
	public FlightSystem flight;
	public Vector3 centerOfBattle;
	public state Aistate=state.Attacking;
	private float dot;
	public float distanceFly=100f;
	public float timestamp;
	private Vector3 randomfoward;
	private float hangtime=5f;
	public GameObject bullet;
	private float shootrate;
	
	
	void Start()
	{
		flight = this.GetComponent<FlightSystem> ();
		flight.AutoPilot = true;
		flight.FollowTarget = true;
		
		
	}
	
	
	void Update()
	{   centerOfBattle= GameObject.FindGameObjectWithTag("Head").transform.position;
		float distance = Vector3.Distance (centerOfBattle, gameObject.transform.position);
		if(distance>distanceFly) Aistate=state.Goback;
		
		switch (Aistate)
		{
			
		case state.Goback: 
			if(Vector3.Distance(gameObject.transform.position,centerOfBattle)<distanceFly)
			{ 
				Aistate=state.Attacking;
				timestamp=Time.time;
			}
			else 
			{  
				flight.PositionTarget=centerOfBattle;
				flight.SpeedUp();
			}
			break;
			
		case state.Attacking:
			if(timestamp+7<Time.time) {
				EnterFlyaway(Random.Range(10,17)); break;}
			
			dot = Vector3.Dot((centerOfBattle-this.transform.position).normalized, this.transform.forward);
			distance=Vector3.Distance(centerOfBattle, this.transform.position);
			
			if(distance<distanceElude) {
				EnterFlyaway(10);
				flight.SpeedDown();
				break;
			}
			
			if (distance>distanceAttack) Aistate=state.CatchUp;
			else if(dot>0.5) attack();
			else EnterFlyaway(5);
			
			break;
			
		case state.Flyaway:
			
			if(timestamp+hangtime<Time.time) 
				Aistate=state.Attacking;	
			break;
			
			
			
		case state.CatchUp:
			if(Vector3.Distance (this.transform.position, centerOfBattle ) >distanceAttack)
			{
				flight.PositionTarget=centerOfBattle;
				flight.SpeedDown();
				break;
			}
			else 
			{ 
				Aistate=state.Attacking;
				timestamp=Time.time;
			}
			break;
		}
		
		
	}
	void attack()
	{
		if(Random.Range(0,100)>80)
			GameObject.Instantiate (bullet,this.transform.position,this.transform.rotation);
	}
	
	void EnterFlyaway(float delta)
	{
		Vector3 tmp;
		hangtime = delta;
		tmp.x = Random.Range (-1, 1);
		tmp.y = Random.Range (-1, 1);
		tmp.z = Random.Range (-1, 1);
		flight.PositionTarget = this.transform.position + tmp * 100;
		Aistate = state.Flyaway;
		timestamp = Time.time;
	}
	
}

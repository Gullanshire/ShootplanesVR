﻿using UnityEngine;
using System.Collections;

public class autoMovePlane : MonoBehaviour
{
	private Vector3 startingPosition;
	private int counter;
	private bool ifrotate;
	private Vector3 lastRotate;
	private int oldScore;

	private int xflag;
	private int yflag;
	private int zflag;

	private float ix;
	private float iy;
	private float iz;
	private Vector3 direction;

	public int s;

	// Use this for initialization
	void Start ()
	{
		startingPosition = transform.localPosition;	
		counter = 0;
		ifrotate = false;
		oldScore = 0;

		xflag = yflag = zflag = 0;
		if (Random.value * 10 >= 6)
			xflag = 1;
		if (Random.value * 10 >= 5)
			yflag = 1;
		if (Random.value * 10 >= 4)
			zflag = 1;
		ix = Random.value % 10;
		iy = 0;
		iz = Random.value % 10;
		startingPosition.y = Random.value * 15;
		transform.localPosition = startingPosition;
	}
	
	// Update is called once per frame
	void Update ()
	{
		//Relocate if the cube is out of range
		if (counter % 24000 == 1 ||transform.localPosition.x >= 3000 || transform.localPosition.y >= 3000 || transform.localPosition.z >= 3000 || transform.localPosition.y <= -3000 || transform.localPosition.x <= -3000 || transform.localPosition.z <= -3000) {
			Vector3 newdirection = Random.onUnitSphere;
			//newdirection.y = Mathf.Clamp (newdirection.y, 0.5f, 1f);
			float newdistance = 10 * Random.value + 1.5f;
			Vector3 newPlace = newdirection * newdistance;
			newPlace.y = 15 * Random.value;
			transform.localPosition = newPlace;
			ix = Random.value % 10;
			iy = 0;
			iz = Random.value % 10;
			if (Random.value * 10 >= 6)
				xflag = 1;
			else xflag = 0;
			if (Random.value * 10 >= 5)
				yflag = 1;
			else yflag = 0;
			if (Random.value * 10 >= 4)
				zflag = 1;
			else zflag = 0;
			ifrotate = false;
			transform.Rotate(lastRotate*(-1));
			oldScore = s;
		}

		//Auto move the cube
		direction.x = (xflag == 1)?ix:(ix * (-1));
		direction.z = (zflag == 1)?iz:(iz * (-1));
		direction.y = (yflag == 1)?iy:(iy * (-1));
		if (!ifrotate) {
			Vector3 rotatedir;
			rotatedir.x = 0;
			if(direction.z >= 0)
				rotatedir.y = Mathf.Atan(direction.x/direction.z)*180/Mathf.PI;
			else rotatedir.y = 180 + Mathf.Atan(direction.x/direction.z)*180/Mathf.PI;
			rotatedir.z = 0 ;
			//transform.LookAt(direction);
			transform.Rotate(rotatedir);
			ifrotate = true;
			lastRotate = rotatedir;
		}
		float distance = 0;
		if (Mathf.Abs (ix) < 0.5 && Mathf.Abs (iy) < 0.5 && Mathf.Abs (iz) < 0.5)
			distance = 0;
		transform.localPosition += direction * distance * (counter/360000+1);

		//Counter
		counter++;
	}
}

using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(BoxCollider))]


public class FlightSystem : MonoBehaviour {
	
	public float Speed = 0.5f;
	public float SpeedMax = 1f;
	private float MoveSpeed = 0.1f;
	public float RotationSpeed = 0.03f;
	public float TurnSpeed = 0.05f;
	public float DampingTarget = 10.0f;
	public bool AutoPilot = true;
	public float SpeedMin = 0.01f;

	
	public bool FollowTarget = false;
	
	public Vector3 PositionTarget = Vector3.zero;
	
	private Vector3 positionTarget = Vector3.zero;
	private Quaternion mainRot = Quaternion.identity;
	[HideInInspector]
	public float roll = 0;
	[HideInInspector]
	public float pitch = 0;
	[HideInInspector]
	public float yaw = 0;
	
	
	void Start () 
	{
		//DamageManage = this.gameObject.GetComponent<DamageManager>();
		//WeaponControl = this.gameObject.GetComponent<WeaponController>();
	}
	
	void FixedUpdate()
	{
		if(!this.rigidbody)
			return;
		
		
		Quaternion AddRot = Quaternion.identity;
		Vector3 velocityTarget = Vector3.zero;
		
		if(AutoPilot){
			if(FollowTarget){
				positionTarget = Vector3.Lerp(positionTarget,PositionTarget,Time.fixedDeltaTime * DampingTarget);
				Vector3 relativePoint = this.transform.InverseTransformPoint(positionTarget).normalized;
				mainRot = Quaternion.LookRotation(positionTarget - this.transform.position);
				rigidbody.rotation = Quaternion.Lerp(rigidbody.rotation,mainRot,Time.fixedDeltaTime * RotationSpeed);
				this.rigidbody.rotation *= Quaternion.Euler(-relativePoint.y * 2,0,-relativePoint.x * 10);
				
			}
			velocityTarget = (rigidbody.rotation * Vector3.forward) * (Speed + MoveSpeed);
		}
		rigidbody.velocity = Vector3.Lerp(rigidbody.velocity,velocityTarget,Time.fixedDeltaTime);
		
		MoveSpeed = Mathf.Lerp(MoveSpeed,Speed,Time.deltaTime);
	}
	
	
	
	
	
	public void SpeedUp(){
		MoveSpeed = Mathf.Lerp(MoveSpeed,SpeedMax,Time.deltaTime * 10);
	}

	public void SpeedDown()
	{
		MoveSpeed = Mathf.Lerp (MoveSpeed, SpeedMax, Time.deltaTime * 10);
	}
	
	void Update(){
		
	}
	
	void OnCollisionEnter(Collision other)
	{
		Debug.Log (other.gameObject.name);
		if(other.gameObject.GetComponent<Rigidbody>())
		{
			Debug.Log (other.gameObject.name);
			Destroy (gameObject);
			
		}
	}
	
	
	
}

﻿using UnityEngine;
using System.Collections;

public class selfBlood : MonoBehaviour {

	public GameObject thePlane;
	private float startX;
	private float startSX;
	public int lastBlood;
	public int blood;

	// Use this for initialization
	void Start () {
		lastBlood = 1000;
		startX = transform.localPosition.x;
		startSX = transform.localScale.x;
	}
	
	// Update is called once per frame
	void Update () {
		if (thePlane!=null){
			int blood = thePlane.GetComponent<bloodControl>().getBlood();
			if (blood != lastBlood) {
				transform.localScale = new Vector3 (startSX * blood * 1.0f / 1000, transform.localScale.y, transform.localScale.z);
				transform.localPosition = new Vector3 (startX - 0.175f * (1000 - blood) / 1000, transform.localPosition.y, transform.localPosition.z);
				lastBlood = blood;
			}
		}
	}
}
﻿using UnityEngine;
using System.Collections;

public class FlyAim : MonoBehaviour {

	public GameObject gameController;

	private float speed;
	
	// Use this for initialization
	void Start () {
		speed = 0.15f;
	}
	
	// Update is called once per frame
	void Update () {
		if (gameController.GetComponent<GameController> ().isFlyLock ()) {
			transform.Translate (Vector3.left * Time.deltaTime * speed);
		} else {
			transform.localPosition = new Vector3 (4, transform.localPosition.y, transform.localPosition.z);
		}
	}
}

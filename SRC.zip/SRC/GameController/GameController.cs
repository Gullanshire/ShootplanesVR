﻿using UnityEngine;
using System.Collections;

public class GameController : MonoBehaviour {

	//All the UIs
	public GameObject sphere;
	public GameObject flightUI;
	public GameObject combatUI;
	public GameObject flyUI;
	public GameObject enemySpawn;
	public GameObject winB;
	public GameObject loseB;
	//----------------------------------------------------------

	//Game Condition: Flight(Inside the space ship), Fly, Combat
	private enum gameCondition
	{
		isCombat = 0,
		isFlight = 1,
		isFly = 2
	};

	gameCondition gCondition;
	//----------------------------------------------------------

	//Combat condition variables
	private bool isLock;//store whether the enemy is locked and is in combat

	public enum enemyType{
		level_1 = 1,
		level_2 = 2,
		level_3 = 3
	};

	public enemyType eType;//Enemy Type
	private bool ifWin;
	private bool ifLose;
	private int winCount;//begin to count when the player wins, and after count down, the scene will be back to flight scene
	//----------------------------------------------------------

	//Flight condition variables
	//......
	//----------------------------------------------------------

	//Fly condition variables
	private bool flyLock;//Whether a plane is being locked in the fly condition
	//----------------------------------------------------------

	//Player information
	private int playerBlood;
	private int playerExp;
	private int playerLevel;
	//----------------------------------------------------------

	//Game information
	private int numOfPlane;
	public int gameDifficulty;

	//----------------------------------------------------------


	// Use this for initialization
	void Start () {
		flyLock = false;

		switch (eType) {
		case enemyType.level_1:
			gameDifficulty = 6;
			break;
		case enemyType.level_2:
			gameDifficulty = 10;
			break;
		case enemyType.level_3:
			gameDifficulty = 15;
			break;
		};
		numOfPlane = 0;
		ifWin = false;
		ifLose = false;
		winCount = 0;
		gCondition = gameCondition.isFly;
		//Initialize the condition, combat condition or flight condition
		isLock = false;
	}
	
	// Update is called once per frame
	void Update () {
		if (gCondition == gameCondition.isCombat) {
			GameObject thePlane = GameObject.FindGameObjectWithTag("Enemy");
			if(!thePlane)
				gCondition = gameCondition.isFly;
		}
		//update the UI
		if(numOfPlane <= 0)
			enemySpawn.GetComponent<EnemySpawner> ().newPlane (gameDifficulty);
		flyUI.SetChildrenActiveRecursively (gCondition == gameCondition.isFly);
		combatUI.SetChildrenActiveRecursively (gCondition == gameCondition.isCombat);
		winB.SetChildrenActiveRecursively (ifWin);
		loseB.SetChildrenActiveRecursively (ifLose);
		if (ifWin) {
			winCount++;
			if (winCount >= 180) {
				winCount = 0;
				Application.LoadLevel ("Flight");
			}
		} else
			winCount = 0;
		if (ifLose) {
			winCount++;
			if (winCount >= 180) {
				winCount = 0;
				Application.LoadLevel ("Flight");
			}
		} else
			winCount = 0;
		if (gCondition == gameCondition.isFlight)
			Application.LoadLevel ("Flight");
	}

	public void setPlane(int setPlaneCount){
		numOfPlane = setPlaneCount;
	}

	public int getPlaneNum(){
		return numOfPlane;
	}

	//Use functions to choose different UI for different condtion
	public void flightCondition(){
		flyLock = false;
		isLock = false;
		gCondition = gameCondition.isFlight;
	}

	public void combatCondition(){
		flyLock = false;
		isLock = false;
		gCondition = gameCondition.isCombat;
	}

	public void flyCondition(){
		flyLock = false;
		isLock = false;
		gCondition = gameCondition.isFly;
	}

	public bool isCombatCondition(){
		return (gCondition == gameCondition.isCombat);
	}

	public bool isFlightCondition(){
		return (gCondition == gameCondition.isFlight);
	}

	public bool isFlyCondition(){
		return (gCondition == gameCondition.isFly);
	}

	public void ifWinOrLose(bool ifwin){
		ifWin = ifwin;
		ifLose = !ifwin;
	}

	public bool returnWin(){
		return ifWin;
	}
	
	public void changeFlyLock(bool isLock){
		flyLock = isLock;
	}

	public bool returnLose(){
		return ifLose;
	}

	public bool isFlyLock(){
		return flyLock;
	}
}

﻿using UnityEngine;
using System.Collections;

public class EnemySpawner : MonoBehaviour {
	
	public GameObject plane;
	
	public GameObject gameController;
	
	private int planeCounter; // count the number of planes
	
	private int counter;
	// Use this for initialization
	void Start () {
		counter = 0;
		planeCounter = gameController.GetComponent<GameController>().getPlaneNum();
		//		GameObject obj = (GameObject)GameObject.Instantiate(plane,transform.position,Quaternion.identity);
		//		obj.tag = "EnemySub";
		//obj.transform.localScale = new Vector3 (10, 10, 10);
		//obj.AddComponent ("autoMovePlane");
	}
	
	// Update is called once per frame
	void Update () {
		counter++;
	}
	
	public void newPlane(int numOfPlane){
		for (int i = 0; i < numOfPlane; i++) {
			planeCounter++;
			Vector3 tmp;
			tmp.x=Random.Range(-10f,10f);
			tmp.y=Random.Range(-10f,10f);
			tmp.z=Random.Range(-10f,10f)+50;
			GameObject obj = (GameObject)GameObject.Instantiate (plane, tmp, Quaternion.identity);
			obj.tag = "EnemySub";
			gameController.GetComponent<GameController>().setPlane(planeCounter);
			//obj.transform.localScale = new Vector3 (10, 10, 10);
			//obj.AddComponent ("autoMovePlane");
		}
	}
}
